/* jshint esversion: 6 */
/**
 * scripts.js
 *
 * This file is only used in Storybook to combine all project JavaScript files
 * into a single entry point that Storybook can import.
 */

import './components/elevation-profile/elevation-profile.js';
import './components/map/map.js';
import './components/stats-bar/stats-bar.js';
import './elements/units-toggle/units-toggle.js';
