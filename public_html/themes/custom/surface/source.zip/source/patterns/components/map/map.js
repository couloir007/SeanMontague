/**
 * map.js
 *
 * Initializes Leaflet maps for the Surface theme.
 * Runs via Drupal.behaviors in Drupal, DOMContentLoaded/setTimeout in Storybook.
 *
 * Configure via data-attributes on the .map element:
 *   data-map-center="44.593,-71.918"     fallback center (used when no geojson)
 *   data-map-zoom="12"                   fallback zoom (used when no geojson)
 *   data-map-interactive="false"         non-interactive bg map (hero)
 *   data-map-geojson="/path/to.geojson"  fetch + draw track, fitBounds all data
 *   data-map-markers='[{...}]'           point markers [{lat,lon,color,label,entity_type,entity_id}]
 *   data-map-lines='[{...}]'             inline polylines (Storybook)
 *   data-map-tiles="usgs-topo"           tile set key (default: usgs-topo)
 *
 * Tile config priority:
 *   1. drupalSettings.trailMapper (set by hook_page_attachments from admin config)
 *   2. data-map-tiles attribute
 *   3. usgs-topo default
 *
 * After init:
 *   window._surfaceMaps[map_id]    — Leaflet map instance
 *   window._surfaceTracks[map_id]  — raw GeoJSON coordinates [lon, lat, ele_ft]
 *   'surface-map-ready' event      — dispatched with { map_id, map, coords }
 */

/* jshint esversion: 6 */
/* global L, Drupal */

(() => {
  "use strict";

  const TILE_SETS = {
    'usgs-topo': {
      url: 'https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer/tile/{z}/{y}/{x}',
      attr: 'Tiles &copy; <a href="https://usgs.gov">USGS</a> The National Map',
      maxZoom: 16,
    },
    'usgs-imagery': {
      url: 'https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryOnly/MapServer/tile/{z}/{y}/{x}',
      attr: 'Tiles &copy; <a href="https://usgs.gov">USGS</a> The National Map',
      maxZoom: 16,
    },
    'usgs-imagery-topo': {
      url: 'https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryTopo/MapServer/tile/{z}/{y}/{x}',
      attr: 'Tiles &copy; <a href="https://usgs.gov">USGS</a> The National Map',
      maxZoom: 16,
    },
    'usgs-shaded': {
      url: 'https://basemap.nationalmap.gov/arcgis/rest/services/USGSShadedReliefOnly/MapServer/tile/{z}/{y}/{x}',
      attr: 'Tiles &copy; <a href="https://usgs.gov">USGS</a> The National Map',
      maxZoom: 16,
    },
    'osm': {
      url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      attr: '&copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19,
    },
  };

  const resolveTile = (el) => {
    // Priority 1 — drupalSettings from hook_page_attachments
    const ds = window.drupalSettings?.trailMapper;
    if (ds?.tileUrl) {
      return { url: ds.tileUrl, attr: ds.tileAttribution ?? '', maxZoom: ds.tileMaxZoom ?? 16 };
    }
    // Priority 2 — data-map-tiles per-element override
    const key = el.dataset.mapTiles ?? 'usgs-topo';
    return TILE_SETS[key] ?? TILE_SETS['usgs-topo'];
  };

  const pinIcon = (color) => L.divIcon({
    html: `<div style="width:10px;height:10px;border-radius:50%;background:${color};border:2px solid #fff;box-shadow:0 1px 6px rgba(0,0,0,0.3)"></div>`,
    iconSize: [10, 10],
    iconAnchor: [5, 5],
    className: '',
  });

  const parseJSON = (str, fallback) => {
    if (!str) return fallback;
    try { return JSON.parse(str); }
    catch { return fallback; }
  };

  const initLeaflet = (el, geojson, { lat, lon, zoom, interactive, markers, lines, tile, mapId }) => {
    const map = L.map(el, {
      center: [lat, lon],
      zoom,
      zoomControl: interactive,
      scrollWheelZoom: false,
      dragging: interactive,
      doubleClickZoom: interactive,
      keyboard: interactive,
    });

    L.tileLayer(tile.url, { maxZoom: tile.maxZoom, attribution: tile.attr }).addTo(map);

    // ── Inline polylines (Storybook fixture data) ──────────────────────────
    lines.forEach((line) => {
      L.geoJSON(
        { type: 'Feature', geometry: { type: 'LineString', coordinates: line.coords } },
        { style: { color: line.color ?? '#3a5a40', weight: line.weight ?? 3, opacity: 0.85, dashArray: line.dash ?? null } }
      ).addTo(map);
    });

    // ── Markers ────────────────────────────────────────────────────────────
    const markerLatLngs = [];
    markers.forEach((m) => {
      const title = m.label?.replace(/<[^>]*>?/gm, '') ?? '';
      const marker = L.marker([m.lat, m.lon], { icon: pinIcon(m.color ?? '#3a5a40'), title })
        .addTo(map)
        .bindPopup(m.label ?? '');

      markerLatLngs.push([m.lat, m.lon]);

      if (m.entity_type && m.entity_id) {
        marker.on('click', () => {
          window.dispatchEvent(new CustomEvent('surface-map-marker-click', {
            detail: { entity_type: m.entity_type, entity_id: m.entity_id, map_id: mapId, lat: m.lat, lon: m.lon },
          }));
        });
      }
    });

    // ── GeoJSON track ──────────────────────────────────────────────────────
    // Add the layer to the map first — Leaflet computes correct bounds
    // from the rendered geometry, then fitBounds on track + markers.
    let coords = null;
    if (geojson) {
      const trackLayer = L.geoJSON(geojson, {
        style: () => ({ color: '#3a5a40', weight: 3, opacity: 0.85 }),
        pointToLayer: (_feature, latlng) => L.circleMarker(latlng, { radius: 4, color: '#3a5a40' }),
      }).addTo(map);

      const bounds = trackLayer.getBounds();
      markerLatLngs.forEach((ll) => bounds.extend(ll));
      map.fitBounds(bounds, { padding: [32, 32] });

      coords = geojson.features?.[0]?.geometry?.coordinates ?? null;
      window._surfaceTracks = window._surfaceTracks ?? {};
      window._surfaceTracks[mapId] = coords;
    } else if (markerLatLngs.length > 1) {
      map.fitBounds(L.latLngBounds(markerLatLngs), { padding: [32, 32] });
    }

    // ── invalidateSize ─────────────────────────────────────────────────────
    requestAnimationFrame(() => map.invalidateSize());
    setTimeout(() => map.invalidateSize(), 150);
    setTimeout(() => map.invalidateSize(), 500);

    // ── Register ───────────────────────────────────────────────────────────
    window._surfaceMaps = window._surfaceMaps ?? {};
    window._surfaceMaps[mapId] = map;
    window._surfaceMapInstance ??= map;

    window.dispatchEvent(new CustomEvent('surface-map-ready', {
      detail: { map_id: mapId, map, coords },
    }));

    // ── Ctrl+scroll / touch gesture hints ─────────────────────────────────
    if (!interactive) return;

    let hintEl = null;
    let hintTimer = null;
    let lastHintTime = 0;
    let scrollWheelTimer = null;

    const getHint = () => {
      if (!hintEl) {
        hintEl = document.createElement('div');
        hintEl.setAttribute('aria-hidden', 'true');
        hintEl.style.cssText =
          'position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);' +
          'background:rgba(0,0,0,0.55);color:#fff;padding:8px 14px;border-radius:4px;' +
          'font-size:13px;line-height:1.3;pointer-events:none;white-space:nowrap;' +
          'opacity:0;transition:opacity 0.15s;z-index:1000;';
        el.appendChild(hintEl);
      }
      return hintEl;
    };

    const showHint = (text) => {
      if (Date.now() - lastHintTime < 3000) return;
      const hint = getHint();
      hint.textContent = text;
      hint.style.opacity = '1';
      clearTimeout(hintTimer);
      hintTimer = setTimeout(() => {
        hint.style.opacity = '0';
        lastHintTime = Date.now();
      }, 1500);
    };

    el.addEventListener('wheel', (e) => {
      if (e.ctrlKey) {
        e.preventDefault();
        map.scrollWheelZoom.enable();
        clearTimeout(scrollWheelTimer);
        scrollWheelTimer = setTimeout(() => map.scrollWheelZoom.disable(), 500);
      } else {
        showHint('Hold Ctrl to zoom');
      }
    }, { passive: false });

    if (window.matchMedia('(pointer: coarse)').matches) {
      el.addEventListener('touchstart', (e) => {
        if (e.touches.length === 1) showHint('Use two fingers to move the map');
      }, { passive: true });
    }
  };

  const initMap = async (el) => {

    if (el._surfaceMapInit) return;
    el._surfaceMapInit = true;

    if (typeof L === 'undefined') {
      console.warn('map: Leaflet not loaded');
      return;
    }

    const [latStr, lonStr] = (el.dataset.mapCenter ?? '44.593,-71.918').split(',');
    const lat = parseFloat(latStr);
    const lon = parseFloat(lonStr);
    const zoom = parseInt(el.dataset.mapZoom ?? '12', 10);
    const interactive = el.dataset.mapInteractive !== 'false';
    const markers = parseJSON(el.dataset.mapMarkers, []);
    const lines = parseJSON(el.dataset.mapLines, []);
    const geojsonUrl = el.dataset.mapGeojson ?? null;
    const mapId = el.id ?? 'map';
    const tile = resolveTile(el);

    const opts = { lat, lon, zoom, interactive, markers, lines, tile, mapId };

    if (geojsonUrl) {
      try {
        const r = await fetch(geojsonUrl);
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const geojson = await r.json();
        initLeaflet(el, geojson, opts);
      } catch (err) {
        console.warn('map: GeoJSON fetch failed', geojsonUrl, err);
        initLeaflet(el, null, opts);
      }
    } else {
      initLeaflet(el, null, opts);
    }
  };

  const initAll = (context) => {
    const root = context ?? document;
    root.querySelectorAll('.map').forEach((el) => initMap(el));
  };

  // Drupal
  if (typeof Drupal !== 'undefined' && Drupal.behaviors) {
    Drupal.behaviors.surfaceMap = {
      attach: (context) => initAll(context),
    };
  }

  // Storybook / standalone
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => initAll());
  } else {
    setTimeout(() => initAll(), 0);
  }
})();
