/* jshint esversion: 11 */
/* global Drupal */

(() => {
  "use strict";

  const STAT_MAP = [
    { key: 'distance',  label: 'Distance',  unit: 'miles',   decimals: 1 },
    { key: 'elev_gain', label: 'Elevation', unit: 'ft gain', decimals: 0 },
    { key: 'elev_loss', label: 'Loss',      unit: 'ft loss', decimals: 0 },
    { key: 'elev_min',  label: 'Min Elev',  unit: 'ft',      decimals: 0 },
    { key: 'elev_max',  label: 'Max Elev',  unit: 'ft',      decimals: 0 },
  ];

  const fmt = (val, decimals) => {
    if (val === null || val === undefined || isNaN(val)) return '—';
    return decimals > 0
      ? parseFloat(val).toFixed(decimals)
      : Math.round(val).toLocaleString();
  };

  const populateBar = (bar, stats) => {
    if (!bar || !stats) return;
    STAT_MAP.forEach((def) => {
      const val = stats[def.key];
      if (val === undefined) return;

      let item = bar.querySelector(`[data-stat="${def.key}"]`);
      if (!item) {
        item = document.createElement('div');
        item.className = 'stats-bar__item';
        item.dataset.stat = def.key;
        item.innerHTML =
          `<span class="stats-bar__label">${def.label}</span>` +
          `<span class="stats-bar__value"></span>` +
          `<span class="stats-bar__unit">${def.unit}</span>`;
        bar.appendChild(item);
      }

      const valueEl = item.querySelector('.stats-bar__value');
      if (valueEl) valueEl.textContent = fmt(val, def.decimals);
    });
  };

  const initStatsBar = (context) => {
    const root = context ?? document;

    // Handle maps already fired before this behavior attached
    root.querySelectorAll('.stats-bar[data-map-id]').forEach((bar) => {
      const mapId = bar.dataset.mapId;
      const map = window._surfaceMaps?.[mapId];
      if (!map) return;
      const coords = window._surfaceTracks?.[mapId];
      if (!coords?.length) return;
      // Re-compute stats from cached coords
      const stats = window._surfaceComputeTrackStats?.(coords);
      if (stats) populateBar(bar, stats);
    });
  };

  window.addEventListener('surface-map-ready', (e) => {
    const { map_id, stats } = e.detail ?? {};
    if (!map_id || !stats) return;
    const bar = document.querySelector(`.stats-bar[data-map-id="${map_id}"]`);
    populateBar(bar, stats);
  });

  if (typeof Drupal !== 'undefined' && Drupal.behaviors) {
    Drupal.behaviors.surfaceStatsBar = {
      attach: (context) => initStatsBar(context),
    };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => initStatsBar());
  } else {
    setTimeout(() => initStatsBar(), 0);
  }

})();
