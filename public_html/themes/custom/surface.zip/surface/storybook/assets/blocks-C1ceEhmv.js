import"./index-8VVP2zUT.js";const{deprecate:o}=__STORYBOOK_MODULE_CLIENT_LOGGER__;o("Import from '@storybook/addon-docs/blocks' is deprecated. Please import from '@storybook/blocks' instead.");
