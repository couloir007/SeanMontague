import{t as d,T as l}from"./twig-DVM_DCke.js";import{D as h,a as p}from"./twig-CTQ74SmP.js";import"./_commonjsHelpers-D6-XlEtG.js";p(l);l.cache(!1);const i=e=>e,c=(e={})=>{const a=d.twig({id:"/media/sean/0c49c450-91fc-4810-9e56-9c253853713d/Shared/www/SeanMontague/public_html/themes/custom/surface/source/patterns/base/prose/prose.twig",data:[{type:"raw",value:`<section class="demo-wysiwyg">
  <div class="just-for-gap">
    <article class="prose">
      <h1>Prose styles and formatting</h1>
      <p class="lead">The ultimate goal for custom and consistent typography formatting and styles is that this should happen without effort by content creators.</p>
      <p>By default, we remove all of the default browser (user agent) styles for most HTML elements on a site such as paragraphs, headings, lists, etc. This results in consistent display of HTML elements across all browsers which only use the styles defined by developers of the project in accordance with branding guidelines.</p>
      <p>When working with large amounts of text on a page (using the <strong>prose class</strong>), We automatically provides custom text styles for most elements you may add to a page. This is also the case when working with components that include text content, the styles for the content has already been addressed and requires no user intervention. The goals is to simplify the content styling process by providing well-formatted and consistent content across the site.</p>
      <hr>
      <h2>Let's see some examples</h2>
      <p>The following are examples of how various HTML elements are styled out of the box.</p>
      <h3>Headings</h3>
      <h1>H1: Only one of these headings is allowed per page</h1>
      <h2>H2: Multiple <code>H2</code> headings can be added to a page</h2>
      <h3>H3: The same applies to <code>H3</code></h3>
      <h4>H4: As well as <code>H4</code></h4>
      <br>
      <h3>Paragraphs</h3>
      <p>Proper spacing in typography is crucial for readability and aesthetic appeal. When styling multiple paragraphs, ensure there is adequate space between lines (line height) and paragraphs (paragraph spacing). This helps readers easily distinguish between different sections and prevents text from appearing cluttered.</p>
      <p>Additionally, consider the margins and padding around the text to create a balanced layout. Consistent spacing throughout the document maintains a clean and professional look. By maintaining uniform spacing, you enhance the overall readability and visual harmony of your typography.</p>

      <h3>When a heading comes after a paragraph</h3>
      <p>When a heading comes after a paragraph, we need a bit more space visually indicate the end of a section or paragraph, and the begining of a new one.</p>
      <h3>Lists</h3>
      <h4>Unordered list:</h4>
      <ul>
        <li>This list item contains <strong>bold text</strong></li>
        <li>In this list item we are adding <em>italic text</em> </li>
        <li>And finally on this item we are including an <a href="#">anchor link</a></li>
      </ul>

      <h4>Ordered list:</h4>
      <ol>
        <li>This list item contains <strong>bold text</strong></li>
        <li>In this list item we are adding <em>italic text</em> </li>
        <li>And finally on this item we are including an <a href="#">anchor link</a></li>
      </ol>

      <h4>Nested lists</h4>
      <ol>
        <li><strong>Campuses:</strong>  The UC system comprises 10 campuses:
          <ul>
            <li>UC Berkeley</li>
            <li>UC Davis</li>
            <li>UC Irvine</li>
            <li>UC Los Angeles (UCLA)</li>
            <li>UC Merced</li>
            <li>UC Riverside</li>
            <li>UC San Diego</li>
            <li>UC San Francisco (graduate/professional only)</li>
            <li>UC Santa Barbara</li>
            <li>UC Santa Cruz</li>
          </ul>
        </li>
        <li><strong>Academic Health Centers: </strong>There are six academic health centers:
          <ul>
            <li>UC Davis Health</li>
            <li>UC San Diego Health</li>
            <li>UCI Health</li>
            <li>UCLA Health</li>
            <li>UCR Health</li>
            <li>UCSF Health</li>
          </ul>
        </li>
        <li><strong>National Laboratories: </strong>UC manages three national laboratories for the U.S. Department of Energy:
          Two items isn't really a list, three is good though.
          <ul>
            <li>Lawrence Berkeley National Laboratory</li>
            <li>Lawrence Livermore National Laboratory</li>
            <li>Los Alamos National Laboratory</li>
          </ul>
        </li>
      </ol>

      <h3>Blockquote</h3>
      <blockquote>
        <p>Typography is the art and technique of arranging type to make written language legible, readable and appealing when displayed.</p>
      </blockquote>

      <h3>Links and buttons</h3>
      <p>Predefined styles available in the WYSIWYG toolbar make it easier for adding links and buttons to a page</p>
      <p><a href="#">This is a plain link</a></p>
      <p>Some examples of buttons include:</p>
      <p>
        <a href="#" class="button button--primary">Primary button</a>
      </p>
      <p>
        <a href="#" class="button button--secondary">Secondary button</a>
      </p>
      <p>
        <a href="#" class="link link--download">Button with icon</a>
      </p>

      <h3>Tables</h3>
      <table>
        <tr>
          <th>Year</th>
          <th>Undergraduate Students</th>
          <th>Graduate Students</th>
          <th>Total Enrollment</th>
        </tr>
        <tr>
          <td>2023-2024</td>
          <td>33,040</td>
          <td>13,638</td>
          <td>46,678</td>
        </tr>
        <tr>
          <td>2022-2023</td>
          <td>32,423</td>
          <td>12,853</td>
          <td>45,276</td>
        </tr>
        <tr>
          <td>2021-2022</td>
          <td>32,122</td>
          <td>12,924</td>
          <td>45,046</td>
        </tr>
      </table>

      <h3>Media</h3>
      <figure>
        <img src="https://images.unsplash.com/photo-1556740758-90de374c12ad?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=1000&amp;q=80" alt="">
        <figcaption>Image caption text</figcaption>
      </figure>

      <p>
      <iframe width="720" height="405" src="https://www.youtube.com/embed/GJVwbyAY4Sk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
      </p>

      <h3>Code blocks</h3>
      <h4>Code blocks</h4>
      <pre>
        <code class="language-js">
          module.exports = {
            export const EventCard = {
              name: 'Event card',
              render: (args) => card(args),
              args: { ...data },
            };
          }
        </code>
      </pre>
    </article>
  </div>
</section>
`,position:{start:0,end:0}}],precompiled:!0});a.options.allowInlineIncludes=!0;try{let n=e.defaultAttributes?e.defaultAttributes:[];return Array.isArray(n)||(n=Object.entries(n)),i(a.render({attributes:new h(n),...e}))}catch(n){return i("An error occurred whilst rendering /media/sean/0c49c450-91fc-4810-9e56-9c253853713d/Shared/www/SeanMontague/public_html/themes/custom/surface/source/patterns/base/prose/prose.twig: "+n.toString())}},f={title:"Base/Prose"},t={render:e=>c(e)};var s,r,o;t.parameters={...t.parameters,docs:{...(s=t.parameters)==null?void 0:s.docs,source:{originalSource:`{
  render: args => prose(args)
}`,...(o=(r=t.parameters)==null?void 0:r.docs)==null?void 0:o.source}}};const y=["Prose"];export{t as Prose,y as __namedExportsOrder,f as default};
