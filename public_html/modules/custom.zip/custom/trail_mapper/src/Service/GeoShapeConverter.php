<?php

namespace Drupal\trail_mapper\Service;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\file\Entity\File;
use Drupal\media\MediaInterface;
use Drupal\node\NodeInterface;
use Drupal\trail_mapper\Form\TrailMapperSettingsForm;

/**
 * Converts GPX and GeoJSON uploads to normalized GeoJSON with Z in meters.
 *
 * Called from trail_mapper_entity_presave() hook. Injected via service
 * container to keep the hook thin and the logic testable.
 *
 * Elevation is stored in meters in GeoJSON. Conversion to feet (or other
 * display units) is handled client-side in map.js based on user preference.
 */
class GeoShapeConverter {

  public function __construct(
    protected readonly FileSystemInterface $fileSystem,
    protected readonly LoggerChannelFactoryInterface $loggerFactory,
    protected readonly EntityTypeManagerInterface $entityTypeManager,
  ) {}

  /**
   * Processes schema_geoshape on a node — converts and overwrites in place.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity being saved.
   */
  public function processEntity(EntityInterface $entity): void {
    if (!$entity instanceof NodeInterface) {
      return;
    }
    if (!$entity->hasField('schema_geoshape')) {
      return;
    }

    $geoshape = $entity->get('schema_geoshape');
    if ($geoshape->isEmpty()) {
      return;
    }

    /** @var \Drupal\media\MediaInterface|null $media */
    $referenced = $geoshape->referencedEntities();
    $media = !empty($referenced) ? reset($referenced) : NULL;
    if (!($media instanceof MediaInterface)) {
      return;
    }

    /** @var \Drupal\file\Entity\File|null $file */
    $file = $media->field_media_file->entity ?? NULL;
    if (!($file instanceof File)) {
      return;
    }

    $uri = $file->getFileUri();
    $extension = strtolower(pathinfo($uri, PATHINFO_EXTENSION));

    $geojson = match ($extension) {
      'gpx'           => $this->convertGpx($uri),
      'geojson', 'json' => $this->normalizeGeoJson($uri),
      default         => NULL,
    };

    if ($geojson === NULL) {
      return;
    }

    $this->overwriteGeoshape($entity, $media, $file, $geojson);

    if ($extension === 'gpx' && TrailMapperSettingsForm::extractWaypointsEnabled()) {
      // $uri captured before overwriteGeoshape mutates $file — original GPX
      // is still on disk; only the file entity record is updated.
      $this->extractWaypoints($uri, $entity);
    }
  }

  /**
   * Converts a GPX file to GeoJSON FeatureCollection with Z in meters.
   *
   * @param string $uri
   *   Drupal stream wrapper URI to the GPX file.
   *
   * @return string|null
   *   JSON-encoded GeoJSON string, or NULL on failure.
   */
  protected function convertGpx(string $uri): ?string {
    $path = $this->fileSystem->realpath($uri);
    if (!$path || !file_exists($path)) {
      $this->loggerFactory->get('trail_mapper')
        ->error('GPX file not found: @uri', ['@uri' => $uri]);
      return NULL;
    }

    libxml_use_internal_errors(TRUE);
    $gpx = simplexml_load_file($path);
    if (!$gpx) {
      $this->loggerFactory->get('trail_mapper')
        ->error('Failed to parse GPX: @uri', ['@uri' => $uri]);
      return NULL;
    }

    $features = [];

    // Support both track (<trk>/<trkseg>/<trkpt>) and
    // route (<rte>/<rtept>) GPX formats.
    foreach ($gpx->trk as $trk) {
      $name = (string) $trk->name ?: 'Track';
      foreach ($trk->trkseg as $seg) {
        $coordinates = $this->extractCoordinates($seg->trkpt);
        if (empty($coordinates)) {
          continue;
        }
        $features[] = $this->makeFeature($coordinates, $name, 'gpx');
      }
    }

    foreach ($gpx->rte as $rte) {
      $name = (string) $rte->name ?: 'Route';
      $coordinates = $this->extractCoordinates($rte->rtept);
      if (empty($coordinates)) {
        continue;
      }
      $features[] = $this->makeFeature($coordinates, $name, 'gpx');
    }

    if (empty($features)) {
      $this->loggerFactory->get('trail_mapper')
        ->warning('No track segments found in GPX: @uri', ['@uri' => $uri]);
      return NULL;
    }

    try {
      return json_encode([
        'type' => 'FeatureCollection',
        'features' => $features,
      ], JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR);
    }
    catch (\JsonException $e) {
      $this->loggerFactory->get('trail_mapper')
        ->error('Failed to encode GPX as GeoJSON: @msg', ['@msg' => $e->getMessage()]);
      return NULL;
    }
  }

  /**
   * Normalizes a GeoJSON file. Z values are kept in meters; display
   * unit conversion is handled client-side.
   *
   * @param string $uri
   *   Drupal stream wrapper URI to the GeoJSON file.
   *
   * @return string|null
   *   JSON-encoded GeoJSON string with Z in meters, or NULL on failure.
   */
  protected function normalizeGeoJson(string $uri): ?string {
    $path = $this->fileSystem->realpath($uri);
    if (!$path || !file_exists($path)) {
      $this->loggerFactory->get('trail_mapper')
        ->error('GeoJSON file not found: @uri', ['@uri' => $uri]);
      return NULL;
    }

    $content = file_get_contents($path);
    if (!$content) {
      return NULL;
    }

    try {
      $data = json_decode($content, TRUE, 512, JSON_THROW_ON_ERROR);
    }
    catch (\JsonException $e) {
      $this->loggerFactory->get('trail_mapper')
        ->error('Invalid JSON in GeoJSON file: @uri — @msg', [
          '@uri' => $uri,
          '@msg' => $e->getMessage(),
        ]);
      return NULL;
    }

    if (!isset($data['type'])) {
      $this->loggerFactory->get('trail_mapper')
        ->error('Invalid GeoJSON structure: @uri', ['@uri' => $uri]);
      return NULL;
    }

    if (isset($data['features'])) {
      foreach ($data['features'] as &$feature) {
        // Z values are stored as-is in meters. Conversion to display units
        // (feet/meters) is handled client-side in map.js.
        $feature['properties']['elevation_unit'] = 'meters';
        $feature['properties']['source'] = $feature['properties']['source'] ?? 'geojson';
      }
      unset($feature);
    }

    try {
      return json_encode($data, JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR);
    }
    catch (\JsonException $e) {
      $this->loggerFactory->get('trail_mapper')
        ->error('Failed to encode GeoJSON: @msg', ['@msg' => $e->getMessage()]);
      return NULL;
    }
  }

  /**
   * Overwrites schema_geoshape with normalized GeoJSON content.
   *
   * After save, schema_geoshape always contains a .geojson file wrapped in
   * a data_download Media entity.
   *
   * @param \Drupal\node\NodeInterface $entity
   *   The node being saved.
   * @param \Drupal\media\MediaInterface $media
   *   The media entity referencing the file.
   * @param \Drupal\file\Entity\File $originalFile
   *   The source file entity inside the media item.
   * @param string $geojson
   *   The normalized GeoJSON string to store.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  protected function overwriteGeoshape(
    NodeInterface $entity,
    MediaInterface $media,
    File $originalFile,
    string $geojson,
  ): void {
    $dir = 'public://geoshape';

    if (!$this->fileSystem->prepareDirectory(
      $dir,
      FileSystemInterface::CREATE_DIRECTORY | FileSystemInterface::MODIFY_PERMISSIONS
    )) {
      $this->loggerFactory->get('trail_mapper')
        ->error('Could not prepare geoshape directory.');
      return;
    }

    $basename = pathinfo($originalFile->getFilename(), PATHINFO_FILENAME);
    $destination = $dir . '/' . $basename . '.geojson';

    $savedUri = $this->fileSystem->saveData(
      $geojson,
      $destination,
      FileSystemInterface::EXISTS_REPLACE
    );

    if (!$savedUri) {
      $this->loggerFactory->get('trail_mapper')
        ->error('Could not save normalized GeoJSON.');
      return;
    }

    $originalFile->setFileUri($savedUri);
    $originalFile->setFilename(basename($savedUri));
    $originalFile->setMimeType('application/geo+json');
    $originalFile->save();

    // Update the media label to match the new filename.
    $media->setName(pathinfo($savedUri, PATHINFO_FILENAME));
    $media->save();

    // Re-attach the media entity. No $entity->save() needed — we are inside
    // hook_entity_presave so the entity saves once with this value already set.
    $entity->set('schema_geoshape', ['target_id' => $media->id()]);
  }

  /**
   * Extracts <wpt> waypoints from a GPX file and creates POI geo entities.
   *
   * Skips waypoints whose coordinates match an existing POI within 0.001°.
   * Country code is inferred from the article's schema_place if available.
   *
   * @param string $uri
   *   Stream wrapper URI to the original GPX file (before overwrite).
   * @param \Drupal\node\NodeInterface $article
   *   The article node being saved.
   */
  protected function extractWaypoints(string $uri, NodeInterface $article): void {
    $path = $this->fileSystem->realpath($uri);
    if (!$path || !file_exists($path)) {
      return;
    }

    libxml_use_internal_errors(TRUE);
    $gpx = simplexml_load_file($path);
    if (!$gpx) {
      return;
    }

    $countryCode = $this->resolveCountryCode($article);
    $created = 0;

    foreach ($gpx->wpt as $wpt) {
      $name = trim((string) $wpt->name);
      if (!$name) {
        continue;
      }
      $lat = (float) $wpt['lat'];
      $lon = (float) $wpt['lon'];
      if ($lat === 0.0 && $lon === 0.0) {
        continue;
      }

      if ($this->poiExistsNearby($lat, $lon)) {
        continue;
      }

      $this->createPoi($name, $lat, $lon, $countryCode);
      $created++;
    }

    if ($created > 0) {
      $this->loggerFactory->get('trail_mapper')->info(
        'Created @count POI(s) from GPX waypoints for node @nid.',
        ['@count' => $created, '@nid' => $article->id()],
      );
    }
  }

  /**
   * Resolves the country code from the article's referenced Place node.
   *
   * @param \Drupal\node\NodeInterface $article
   *   The article node.
   *
   * @return string|null
   *   ISO 3166-1 alpha-2 country code, or NULL if unavailable.
   */
  protected function resolveCountryCode(NodeInterface $article): ?string {
    if (!$article->hasField('schema_place') || $article->get('schema_place')->isEmpty()) {
      return NULL;
    }
    $place = $article->schema_place->entity;
    if (!$place || !$place->hasField('schema_address') || $place->get('schema_address')->isEmpty()) {
      return NULL;
    }
    return $place->schema_address->country_code ?: NULL;
  }

  /**
   * Checks whether a geo_entity:poi with matching coordinates already exists.
   *
   * @param float $lat
   *   Latitude to check.
   * @param float $lon
   *   Longitude to check.
   *
   * @return bool
   *   TRUE if a POI exists within 0.001° on both axes.
   */
  protected function poiExistsNearby(float $lat, float $lon): bool {
    $storage = $this->entityTypeManager->getStorage('geo_entity');
    $ids = $storage->getQuery()
      ->condition('bundle', 'poi')
      ->accessCheck(FALSE)
      ->execute();

    if (empty($ids)) {
      return FALSE;
    }

    foreach ($storage->loadMultiple($ids) as $poi) {
      if ($poi->get('schema_geo')->isEmpty()) {
        continue;
      }
      $item = $poi->get('schema_geo')->first();
      $existingLat = (float) $item->get('lat')->getValue();
      $existingLon = (float) $item->get('lon')->getValue();
      if (abs($existingLat - $lat) <= 0.001 && abs($existingLon - $lon) <= 0.001) {
        return TRUE;
      }
    }

    return FALSE;
  }

  /**
   * Creates a new geo_entity:poi from waypoint data.
   *
   * @param string $name
   *   Waypoint name — becomes the entity label.
   * @param float $lat
   *   Latitude.
   * @param float $lon
   *   Longitude.
   * @param string|null $countryCode
   *   ISO 3166-1 alpha-2 country code for schema_address, or NULL.
   */
  protected function createPoi(string $name, float $lat, float $lon, ?string $countryCode): void {
    $values = [
      'bundle'     => 'poi',
      'label'      => $name,
      'schema_geo' => ['value' => 'POINT (' . $lon . ' ' . $lat . ')'],
    ];

    if ($countryCode) {
      $values['schema_address'] = ['country_code' => $countryCode];
    }

    try {
      $this->entityTypeManager->getStorage('geo_entity')
        ->create($values)
        ->save();
    }
    catch (\Exception $e) {
      $this->loggerFactory->get('trail_mapper')->error(
        'Failed to create POI "@name": @msg',
        ['@name' => $name, '@msg' => $e->getMessage()],
      );
    }
  }

  /**
   * Extracts [lon, lat, elevation_m] coordinates from GPX point elements.
   *
   * @param \SimpleXMLElement $points
   *   Collection of GPX point elements (trkpt or rtept).
   *
   * @return array
   *   Array of coordinate arrays [lon, lat] or [lon, lat, ele_m].
   */
  protected function extractCoordinates(\SimpleXMLElement $points): array {
    $coordinates = [];
    foreach ($points as $pt) {
      $lon = (float) $pt['lon'];
      $lat = (float) $pt['lat'];
      // GPX elevation in meters — stored as-is; conversion handled in map.js.
      $ele = isset($pt->ele)
        ? round((float) $pt->ele, 4)
        : NULL;
      $coordinates[] = $ele !== NULL
        ? [$lon, $lat, $ele]
        : [$lon, $lat];
    }
    return $coordinates;
  }

  /**
   * Builds a GeoJSON Feature from coordinates.
   *
   * @param array $coordinates
   *   Array of coordinate arrays.
   * @param string $name
   *   Feature name for properties.
   * @param string $source
   *   Source format (gpx, geojson).
   *
   * @return array
   *   GeoJSON Feature array.
   */
  protected function makeFeature(array $coordinates, string $name, string $source): array {
    return [
      'type' => 'Feature',
      'geometry' => [
        'type' => 'LineString',
        'coordinates' => $coordinates,
      ],
      'properties' => [
        'name' => $name,
        'source' => $source,
        'elevation_unit' => 'meters',
      ],
    ];
  }

}
